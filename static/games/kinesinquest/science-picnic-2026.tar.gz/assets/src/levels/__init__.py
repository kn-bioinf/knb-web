"""Pakiet levels - poziomy gry."""
